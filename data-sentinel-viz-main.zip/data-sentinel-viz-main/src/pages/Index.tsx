import { DataCenterDashboard } from '@/components/dashboard/DataCenterDashboard';

const Index = () => {
  return <DataCenterDashboard />;
};

export default Index;
